from .models import User,Job_Seeker,College,Recruiter,Job,Admin

__all__ = [User,Job_Seeker,College,Recruiter,Job,Admin]
